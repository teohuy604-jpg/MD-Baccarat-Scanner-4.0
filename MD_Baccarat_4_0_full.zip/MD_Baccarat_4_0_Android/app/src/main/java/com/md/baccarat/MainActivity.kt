package com.md.baccarat

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequest = 4100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        layout.addView(TextView(this).apply {
            text = "🤖 MD BACCARAT SCANNER 4.0\n\nChế độ kết hợp: cửa sổ nổi + chia sẻ màn hình"
            textSize = 20f
        })
        layout.addView(Button(this).apply {
            text = "1. Cấp quyền cửa sổ nổi"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else Toast.makeText(this@MainActivity, "Đã có quyền cửa sổ nổi", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(Button(this).apply {
            text = "2. Bật cửa sổ nổi"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Hãy cấp quyền cửa sổ nổi trước", Toast.LENGTH_LONG).show()
                } else startService(Intent(this@MainActivity, OverlayService::class.java))
            }
        })
        layout.addView(Button(this).apply {
            text = "3. Chia sẻ màn hình để quét"
            setOnClickListener {
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
            }
        })
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("captureData", data)
            }
            startForegroundService(service)
            Toast.makeText(this, "Đã cấp quyền chia sẻ màn hình cho phiên quét", Toast.LENGTH_LONG).show()
        }
    }
}
