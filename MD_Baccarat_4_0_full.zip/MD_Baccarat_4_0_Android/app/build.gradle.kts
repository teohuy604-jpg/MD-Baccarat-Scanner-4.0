plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.md.baccarat"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.md.baccarat"
        minSdk = 26
        targetSdk = 35
        versionCode = 40
        versionName = "4.0-prototype"
    }
}
