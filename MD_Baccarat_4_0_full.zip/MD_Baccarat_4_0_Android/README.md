# MD Baccarat Scanner 4.0 – Android starter

Đây là **bộ khung mã nguồn Android Studio**, chưa phải APK hoàn chỉnh.

## Đã dựng khung
- Màn hình xin quyền overlay và bật cửa sổ nổi Android.
- Yêu cầu người dùng chủ động cấp quyền MediaProjection để chia sẻ màn hình.
- Foreground service giữ phiên MediaProjection.
- Cấu hình project Android/Kotlin.

## Chưa triển khai
- ImageReader/VirtualDisplay để lấy từng frame.
- Crop vùng Player/Banker theo layout bàn chơi.
- AI phát hiện và phân loại rank/suit của lá bài.
- Logic luật rút lá thứ ba đầy đủ để kiểm tra ván từ ảnh.
- Đồng bộ dữ liệu từ bộ nhận diện vào overlay.
- Kiểm thử và build APK ký phát hành.

## Mở project
Mở thư mục này bằng Android Studio (JDK/Android SDK phù hợp), sync Gradle rồi build để kiểm tra. Có thể cần cập nhật Gradle Plugin/SDK theo môi trường Android Studio.

## Quyền riêng tư
Chỉ bắt đầu chia sẻ màn hình sau khi người dùng bấm nút và chấp thuận hộp thoại hệ thống. Không có chức năng đọc ngầm màn hình.

## Build APK bằng GitHub Actions (không cần máy tính)

1. Trên điện thoại, đăng nhập GitHub và tạo repository mới, ví dụ `md-baccarat-scanner`.
2. Giải nén ZIP này bằng ứng dụng quản lý tệp. Tải các tệp/thư mục bên trong `MD_Baccarat_4_0_Android` lên repository, giữ nguyên cấu trúc và thư mục ẩn `.github`.
3. Mở tab **Actions** của repository. Nếu GitHub hỏi, chọn bật Actions.
4. Chọn workflow **Build Android APK** rồi bấm **Run workflow** (hoặc push lên nhánh `main` để tự chạy).
5. Khi workflow chạy xong, mở lần chạy thành công, kéo xuống **Artifacts**, tải `MD-Baccarat-Scanner-debug-apk` và giải nén để lấy `app-debug.apk`.
6. Mở APK trên điện thoại để cài. Android có thể yêu cầu cho phép cài ứng dụng từ nguồn này.

Lưu ý: workflow chỉ đóng gói bản prototype hiện tại. APK nếu build thành công vẫn chưa có AI nhận diện lá bài, chưa có luồng xử lý ảnh màn hình hoàn chỉnh và chưa phải bản phát hành đã kiểm thử. Không tải lên GitHub mật khẩu, token hoặc thông tin đăng nhập.
